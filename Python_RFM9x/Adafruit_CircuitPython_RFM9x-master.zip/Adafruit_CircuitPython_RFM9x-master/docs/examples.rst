Simple test
------------

Ensure your device works with this simple test.

.. literalinclude:: ../examples/rfm9x_simpletest.py
    :caption: examples/rfm9x_simpletest.py
    :linenos:
